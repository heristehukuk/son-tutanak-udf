"""Case folder management module."""
